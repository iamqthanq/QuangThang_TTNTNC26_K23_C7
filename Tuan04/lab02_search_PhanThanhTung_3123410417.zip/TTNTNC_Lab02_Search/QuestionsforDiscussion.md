# Mục 4.3: Câu hỏi thảo luận (Questions for Discussion)

---

## CÂU 6: KHI NÀO BFS DÙNG NHIỀU BỘ NHỚ HƠN A*? VÌ SAO HEURISTIC TỐT LÀM GIẢM VÙNG TRẠNG THÁI PHẢI KHẢO SÁT?

### 1. Khi nào BFS sử dụng nhiều bộ nhớ hơn A*?
Trong hầu hết các bài toán tìm kiếm có không gian trạng thái từ trung bình đến lớn (đặc biệt là các mê cung có không gian rộng thoáng như `open_maze`, `medium_maze`, `empty_maze`), BFS sử dụng nhiều bộ nhớ hơn A* rất đáng kể vì:

* **Bản chất của BFS (Mở rộng đẳng hướng - Uninformed):** BFS hoàn toàn không có thông tin về vị trí đích (Goal). Do đó, thuật toán buộc phải duyệt lan tỏa đều đặn ra mọi hướng theo từng tầng độ sâu $d = 1, 2, 3\dots$. Với hệ số phân nhánh trung bình $b$, số trạng thái ở độ sâu $d$ tăng theo cấp số nhân $O(b^d)$. Toàn bộ các trạng thái này phải lưu đồng thời trong Frontier (Queue) và tập `reached`.
* **Bản chất của A* (Mở rộng hướng đích - Informed):** A* sử dụng hàm đánh giá $f(n) = g(n) + h(n)$. Nhờ có hàm heuristic $h(n)$ dẫn đường, A* ưu tiên mở rộng các nút hướng thẳng về phía đích. Không gian tìm kiếm của A* được bóp hẹp lại thành một dải hẹp dọc theo trục Start $\to$ Goal, thay vì lan tỏa 360 độ như BFS.
* **Minh chứng từ số liệu thực nghiệm Lab 02:**
  * Ở `open_maze`: BFS phải mở rộng tới **682** trạng thái, trong khi A* chỉ mở rộng **535** trạng thái (giảm hơn 21%). Frontier lớn nhất của BFS phình to rất nhanh khi gặp không gian thoáng.
  * Ở `small_maze`: BFS duyệt **92** trạng thái, trong khi A* chỉ duyệt **53** trạng thái (tiết kiệm hơn 42% số nút mở rộng).
* **Trường hợp ngoại lệ (khi nào bộ nhớ tương đương?):** 
  * Khi mê cung chỉ có một đường độc đạo duy nhất (như `large_maze`), cả BFS và A* đều bị ép phải đi theo hành lang đó (đều mở rộng 210 nút).
  * Khi heuristic $h(n) = 0$ (A* thoái hóa về Uniform-Cost Search / BFS).
  * Khi mê cung có tường chắn phức tạp gây sai lệch hướng heuristic làm A* phải mở rộng gần như toàn bộ mê cung trước khi tìm thấy đường vòng.

---

### 2. Vì sao Heuristic tốt làm giảm vùng trạng thái phải khảo sát?
Heuristic tốt giúp giảm mạnh không gian khảo sát dựa trên nguyên lý cắt tỉa tối ưu (Optimal Pruning) của A*:

* **Nguyên lý cắt tỉa theo đường đồng mức $C^*$:** Gọi $C^*$ là chi phí của đường đi tối ưu từ Start đến Goal. Một tính chất cốt lõi của A* (với $h$ admissible/consistent) là: **Thuật toán chỉ mở rộng những nút $n$ thỏa mãn $f(n) \le C^*$. Những nút có $f(n) > C^*$ sẽ KHÔNG BAO GIỜ bị lấy khỏi hàng đợi ưu tiên để mở rộng.**
* **Tác dụng định hướng của heuristic sát thực tế:** Một hàm heuristic tốt là hàm ước lượng sát với chi phí thực tế $h^*(n)$. Khi đó, các nút thuộc các nhánh đi chệch hướng hoặc đi lùi xa đích sẽ có giá trị $h(n)$ tăng nhanh, khiến $f(n) = g(n) + h(n)$ nhanh chóng vượt quá ngưỡng $C^*$. Toàn bộ các nhánh rẽ sai lầm đều bị chặn lại trong Frontier mà không bị tốn công mở rộng.
* **So sánh trực quan với BFS:** BFS tương đương với việc dùng $h(n) = 0$, tức là $f(n) = g(n)$. Mọi nút có chi phí $g(n) < C^*$ đều bị BFS mở rộng bất kể nút đó đi đúng hướng hay ngược hướng với đích. Kết quả là BFS khảo sát toàn bộ hình cầu bán kính $C^*$, tốn bộ nhớ gấp nhiều lần A*.

---
## CÂU 7: TẠI SAO DFS CÓ THỂ CHO ĐƯỜNG ĐI RẤT DÀI HOẶC GẶP VẤN ĐỀ TRONG MÔI TRƯỜNG CÓ CHU TRÌNH?

### 1. Bản chất cơ chế tìm kiếm của DFS (Depth-First Search)
* **Nguyên lý ngăn xếp (LIFO - Last-In, First-Out):** DFS luôn ưu tiên lấy trạng thái vừa được sinh ra gần nhất ở đỉnh Frontier (Stack) để mở rộng tiếp. Thuật toán kiên quyết đi sâu dọc theo một nhánh duy nhất cho tới khi chạm đến nút lá (ngõ cụt) hoặc đạt giới hạn độ sâu trước khi thực hiện quay lui (*backtracking*).
* **Mở rộng không thông tin (Uninformed) và mù chi phí:** DFS hoàn toàn không xét đến hàm chi phí đường đi $g(n)$ (khoảng cách thực tế đã đi từ điểm xuất phát) cũng như không có hàm heuristic $h(n)$ dẫn đường về đích. Do đó, DFS mở rộng các nút chỉ dựa trên quy tắc cấu trúc ngăn xếp mà không hề nhận biết được mình đang đi gần lại hay ngày càng xa rời đích.

---

### 2. Vì sao DFS có thể cho đường đi rất dài (Suboptimal / Extreme Path Length)?
1. **Lựa chọn nhánh rẽ sai lầm ngay từ đầu:**
   * Giả sử tại điểm Start, DFS có 2 hướng rẽ: Hướng $A$ dẫn thẳng tới Goal chỉ sau 2 bước ($g = 2$), hướng $B$ dẫn vào một mê lộ ngoằn ngoèo dài 500 bước trước khi vòng lại đích.
   * Nếu hướng $B$ được đưa vào Stack sau cùng (nằm ở đỉnh Stack), DFS sẽ lập tức mở rộng theo hướng $B$ và lùng sục toàn bộ chiều sâu của nhánh này. Ngay cả khi điểm Goal nằm ngay sát bên cạnh điểm Start (chỉ cách 1 bức tường hoặc 1 ô), DFS vẫn đi hết toàn bộ chiều dài của nhánh $B$ rồi mới chạm đích.
2. **Không có cơ chế tự động sửa sai theo chi phí ngắn nhất:**
   * Khác với BFS (luôn mở rộng theo từng tầng $d = 1, 2, 3\dots$), DFS tìm thấy đường đi nào đầu tiên thì sẽ trả về ngay đường đi đó làm lời giải.
   * Kết quả là DFS **không bảo đảm tính tối ưu (Not Optimal)** và thường trả về các đường đi vòng vèo, lượn sóng, có độ dài lớn gấp hàng chục đến hàng trăm lần so với đường đi tối ưu $d^*$.

---

### 3. Vấn đề của DFS trong môi trường có chu trình (Cycles / Graph Loops)
Trong không gian đồ thị hoặc mê cung có đường vòng khép kín (như `open_maze`, `loops_maze`, `empty_maze`), DFS đối mặt với những vấn đề nghiêm trọng:

* **Hiện tượng lặp vô hạn (Infinite Loops) trên Tree Search:**
  * Nếu thuật toán tìm kiếm theo cây (*Tree Search*) không có cơ chế kiểm tra trạng thái lặp (*Cycle Checking*), tác tử sẽ di chuyển qua lại giữa 2 ô kề nhau (ví dụ: $(x, y) \to (x+1, y) \to (x, y) \to \dots$) hoặc quay vòng tròn trong chu trình kín.
  * Khi đó, độ sâu tối đa của cây tìm kiếm trở thành vô hạn ($m = \infty$). DFS sẽ rơi vào nhánh vô tận không lối thoát, dẫn đến việc **mất tính đầy đủ (Incomplete - không bao giờ dừng lại dù nghiệm tồn tại)**.
* **Bùng nổ không gian và thời gian khi chỉ dùng Path Checking:**
  * Kỹ thuật kiểm tra chu trình trên đường đi (*Path / Branch Checking*) chỉ đảm bảo không có nút nào xuất hiện 2 lần trên *cùng một nhánh tổ tiên*.
  * Tuy nhiên, trong không gian mở có nhiều đường giao nhau, cùng một vị trí ô $(x, y)$ có thể được tiếp cận từ vô số nhánh tìm kiếm khác nhau. DFS sẽ liên tục mở rộng lại trạng thái đó trên các nhánh mới, khiến số lượng nút sinh ra bùng nổ theo cấp số nhân, làm tràn bộ nhớ hoặc cạn kiệt ngân sách tìm kiếm (*max tries/budget exhausted*).

---

### 4. Dẫn chứng số liệu thực nghiệm trong Lab 02

| Bản đồ mê cung | Chiều dài đường đi BFS ($d^*$) | Chiều dài đường đi DFS | Nhận xét thực nghiệm từ Notebook |
| :--- | :---: | :---: | :--- |
| **`02_Maze_Example.ipynb`** (Deterministic vs Random) | **16 bước** | **26 bước** (khi đi theo thứ tự `SENW`)<br>**1.550 bước** (khi chọn hướng ngẫu nhiên `random=True`) | Với hướng ngẫu nhiên, DFS đi lòng vòng qua 125 ô trống, tạo ra đường đi dài gấp **96 lần** so với BFS. |
| **`open_maze`** (`05_Cycle_checking.ipynb`) | **54 bước** | **Hết ngân sách (500 lượt pop)** với phương án `path` & `unique` | DFS bị kẹt trong mê lộ của không gian mở, liên tục mở rộng lại các trạng thái trùng qua nhiều nhánh khác nhau. |
| **`small_maze`** (`Ex1_Maze.ipynb`) | **19 bước** | **45 bước** (chi phí cao hơn gấp 2.3 lần) | DFS chọn nhánh đi vòng quanh biên mê cung trước khi quay vào tâm đích. |

---

---

## CÂU 8: TẠI SAO THỨ TỰ SINH CÁC TRẠNG THÁI CON ẢNH HƯỞNG MẠNH ĐẾN DFS NHƯNG ÍT ẢNH HƯỞNG HƠN ĐẾN BFS?

### 1. Bản chất cấu trúc lưu trữ: Queue (FIFO) vs Stack (LIFO)
* **BFS sử dụng Hàng đợi FIFO (First-In, First-Out):** Nút nào vào trước sẽ được lấy ra mở rộng trước. BFS duyệt toàn bộ không gian trạng thái theo từng lát cắt đồng mức (tầng độ sâu $d = 1$, sau đó đến toàn bộ $d = 2$, rồi $d = 3\dots$).
* **DFS sử dụng Ngăn xếp LIFO (Last-In, First-Out):** Nút nào vào sau cùng sẽ được lấy ra mở rộng ngay lập tức. DFS phát triển sâu theo một nhánh dọc duy nhất cho đến tận cùng.

---

### 2. Tác động của thứ tự sinh trạng thái con lên DFS: CỰC KỲ MẠNH (Quyết định quỹ đạo toàn cục)
Khi một nút cha sinh ra 4 trạng thái con theo thứ tự di chuyển, ví dụ: Bắc (N), Đông (E), Nam (S), Tây (W):
1. **Trạng thái con cuối cùng chi phối hướng đi kế tiếp:** Trong cài đặt ngăn xếp LIFO chuẩn, trạng thái con cuối cùng được `push` vào Stack (hướng Tây - W) sẽ nằm ở đỉnh Stack và được `pop` ra mở rộng ngay ở bước tiếp theo.
2. **Chuyển dịch hoàn toàn nhánh không gian tìm kiếm:**
   * Nếu thứ tự sinh ưu tiên hướng dẫn thẳng về phía Goal (nhánh thuận lợi): DFS chỉ cần mở rộng một chuỗi nút thẳng hàng và chạm đích cực nhanh với số nút duyệt tối thiểu.
   * Nếu thứ tự sinh vô tình đưa một nhánh dẫn vào ngõ cụt xa xôi lên đỉnh Stack: DFS sẽ bị hút sâu vào toàn bộ nhánh sai lầm đó, mở rộng kiệt quệ mọi phân nhánh con cháu rồi mới quay lui trở lại.
3. **Thay đổi toàn diện kết quả đầu ra:** Đổi thứ tự sinh con trong DFS làm thay đổi hoàn toàn:
   * Số lượng trạng thái đã duyệt (Expanded nodes / Reached states).
   * Thời gian thực thi.
   * Hình dạng và độ dài của đường đi tìm được.

---

### 3. Tác động của thứ tự sinh trạng thái con lên BFS: ÍT ẢNH HƯỞNG (Bảo toàn tính tối ưu)
1. **Ràng buộc theo tầng độ sâu $d$:**
   * BFS buộc phải mở rộng kiệt toàn bộ các nút ở tầng $d$ trước khi chạm tới bất kỳ nút nào ở tầng $d+1$.
   * Dù trạng thái con được đưa vào Queue theo thứ tự `NESW` hay `WSEN`, tất cả các con này đều có cùng độ sâu $g(n) = d+1$ và phải xếp hàng chờ đợi phía sau các nút ở tầng hiện tại.
2. **Vai trò chỉ dừng ở mức phá hòa (Tie-breaking) trong cùng một tầng:**
   * Thứ tự sinh con trong BFS chỉ quyết định nút nào **trong cùng một tầng độ sâu** được kiểm tra đích trước.
   * Sự chênh lệch (nếu có) về số nút mở rộng giữa các thứ tự sinh hướng khác nhau chỉ xảy ra ở tầng độ sâu cuối cùng chứa đích (tầng $d^*$), và mức chênh lệch tối đa không vượt quá số nút của tầng đó.
3. **Bảo đảm tính tất định về độ dài nghiệm:**
   * Độ dài đường đi tìm được của BFS **LUÔN CỐ ĐỊNH VÀ BẰNG ĐÚNG CHI PHÍ TỐI ƯU $d^*$**, hoàn toàn bất biến trước mọi thứ tự sinh trạng thái con.

---

### 4. Bảng tổng hợp so sánh độ nhạy cảm với thứ tự sinh trạng thái con

| Tiêu chí so sánh | Depth-First Search (DFS) | Breadth-First Search (BFS) |
| :--- | :--- | :--- |
| **Cấu trúc Frontier** | **Ngăn xếp (Stack - LIFO)** | **Hàng đợi (Queue - FIFO)** |
| **Phương thức duyệt** | Đi sâu theo từng nhánh dọc | Lan tỏa đồng đều theo từng tầng ngang |
| **Mức độ ảnh hưởng của thứ tự sinh hướng** | **Cực kỳ nhạy cảm và khó dự đoán:** Thay đổi toàn bộ quỹ đạo tìm kiếm toàn cục. | **Rất thấp:** Chỉ thay đổi thứ tự xét duyệt cục bộ giữa các nút cùng độ sâu. |
| **Ảnh hưởng đến độ dài lời giải (Path length)** | **Biến động dữ dội:** Có thể từ rất ngắn (may mắn) đến cực dài (hàng nghìn bước). | **Bất biến (Không đổi):** Luôn tìm ra đường đi tối ưu ngắn nhất $d^*$. |
| **Ảnh hưởng đến số nút mở rộng (Expanded Nodes)** | **Biến thiên rất lớn:** Phụ thuộc hoàn toàn vào nhánh được ưu tiên ở đỉnh Stack. | **Biến thiên rất nhỏ:** Chỉ sai khác một vài nút ở tầng độ sâu cuối cùng. |
| **Tính tất định (Deterministic)** | Nhạy cảm với thứ tự cài đặt/ngẫu nhiên. | Kết quả độ dài nghiệm luôn tất định. |

---

### 5. Dẫn chứng thực nghiệm trực quan từ Notebooks Lab 02
Trong [`02_Maze_Example.ipynb`](file:///c:/Code/TTNTNC_Lab02_Search/02_Maze_Example.ipynb) (thử nghiệm hàm `ts.set_order()` trên cùng một mê cung):
* **BFS:** Luôn trả về kết quả lời giải có độ dài **16 bước** (tối ưu tuyệt đối) bất kể thứ tự duyệt hướng.
* **DFS khi đổi thứ tự sinh hướng:**
  * Thứ tự `SENW`: Đường đi dài **26 bước**, mở rộng 53 ô.
  * Thứ tự `Random` (chọn ngẫu nhiên tại mỗi bước): Đường đi bùng nổ lên **1.550 bước**, mở rộng 125 ô (lang thang khắp bản đồ).
  * Thứ tự `NESW` (ngăn xếp lấy W trước): Dẫn tác tử đâm thẳng vào các bức tường ngõ cụt phía Tây trước khi có thể quay đầu sang hướng Đông để tìm đích.

---

## CÂU 9: SO SÁNH GBFS VÀ A*: THUẬT TOÁN NÀO SỬ DỤNG g(n), h(n), f(n)? ẢNH HƯỞNG ĐẾN TÍNH TỐI ƯU NHƯ THẾ NÀO?

### 1. Sử dụng các thành phần $g(n)$, $h(n)$, $f(n)$
Sự khác biệt cốt lõi giữa Greedy Best-First Search (GBFS) và A* nằm ở cấu trúc hàm đánh giá $f(n)$:

| Tiêu chí | Greedy Best-First Search (GBFS) | A* Search |
| :--- | :--- | :--- |
| **Hàm đánh giá $f(n)$** | $f(n) = h(n)$ | $f(n) = g(n) + h(n)$ |
| **Ý nghĩa thành phần** | Chỉ dùng $h(n)$ (ước lượng chi phí còn lại từ $n$ tới Goal). Hoàn toàn bỏ qua chi phí đã đi $g(n)$. | Kết hợp cả $g(n)$ (chi phí thực tế đã đi từ Start tới $n$) và $h(n)$ (ước lượng chi phí còn lại tới Goal). |
| **Chiến lược tìm kiếm** | **Tham lam thuần túy (Myopic / Short-sighted):** Luôn chọn nút có vẻ gần đích nhất ở bước tiếp theo. | **Cân bằng toàn diện (Optimal Trade-off):** Chọn nút có tổng chi phí toàn chặng dự kiến là thấp nhất. |

---

### 2. Ảnh hưởng đến tính tối ưu (Optimality)

* **GBFS KHÔNG bảo đảm tính tối ưu:**
  * Vì GBFS hoàn toàn bỏ qua $g(n)$, thuật toán chỉ cố gắng giảm khoảng cách $h(n)$ mà không quan tâm đoạn đường đã đi dài bao nhiêu. Hậu quả là GBFS thường chọn các đường vòng vèo, chi phí rất cao.
  * **Dẫn chứng thực nghiệm Lab 02:**
    * Ở `small_maze`: Đường tối ưu của A* và BFS là **19 bước**, nhưng GBFS cho đường dài tới **29 bước** (dư 10 bước).
    * Ở `medium_maze`: A* đi **68 bước**, GBFS đi **74 bước**.
    * Ở `L_maze`: A* đi **16 bước**, trong khi GBFS đi tới **24 bước**.
  * **Hiện tượng bẫy vật cản lõm (Concave Obstacles):** Khi gặp chướng ngại vật dạng chữ U hoặc ngõ cụt chắn trước mặt đích, GBFS sẽ mù quáng lao thẳng vào đáy ngõ cụt vì các ô ở đáy có giá trị $h(n)$ nhỏ nhất. Nó phải mở rộng kiệt quệ toàn bộ lòng chảo rồi mới chịu quay đầu ra.
* **A* LUÔN bảo đảm tính tối ưu:**
  * Nhờ kết hợp $g(n)$, A* kiểm soát tổng chi phí thực tế. Nếu một nhánh rẽ đi vào ngõ cụt hoặc đi vòng, giá trị $g(n)$ tăng cao sẽ làm $f(n)$ vượt quá chi phí các nhánh khác, buộc thuật toán tự động quay lui xét nhánh triển vọng hơn.
  * **Điều kiện tối ưu:**
    * Trên **Tree Search**: A* tối ưu khi $h(n)$ là *Admissible* (không bao giờ đánh giá quá cao chi phí thực tế).
    * Trên **Graph Search**: A* tối ưu khi $h(n)$ là *Consistent* (thỏa mãn bất đẳng thức tam giác).

---

## CÂU 10: MANHATTAN VÀ EUCLIDEAN KHÁC NHAU RA SAO TRONG LƯỚI CHỈ CHO PHÉP ĐI LÊN/XUỐNG/TRÁI/PHẢI?

### 1. Bản chất hình học và công thức toán học
Trong không gian lưới 2D của bài toán mê cung, tác tử chỉ có 4 hành động hợp lệ: Bắc (N), Đông (E), Nam (S), Tây (W) với chi phí mỗi bước $c = 1$. Khoảng cách giữa ô $n(x_n, y_n)$ và ô $\text{Goal}(x_g, y_g)$ được định nghĩa:
* **Khoảng cách Manhattan ($L_1$ Norm):**
  $$h_{\text{Manhattan}}(n) = |x_n - x_g| + |y_n - y_g|$$
  Đo khoảng cách dọc theo các cạnh vuông góc của lưới ô cờ.
* **Khoảng cách Euclidean ($L_2$ Norm):**
  $$h_{\text{Euclidean}}(n) = \sqrt{(x_n - x_g)^2 + (y_n - y_g)^2}$$
  Đo khoảng cách theo đường chim bay thẳng xuyên qua không gian liên tục.

---

### 2. Sự khác biệt cụ thể trên không gian lưới 4 hướng di chuyển

| Đặc tính so sánh | Manhattan Distance ($L_1$) | Euclidean Distance ($L_2$) |
| :--- | :--- | :--- |
| **Mô hình di chuyển giả định** | Di chuyển từng bước thẳng trên lưới rời rạc (4 hướng). Đúng với tập hành động thực tế của bài toán. | Di chuyển tự do theo đường chéo thẳng trong không gian liên tục (không bị ràng buộc bởi ô lưới). |
| **Quan hệ với chi phí thật $h^*(n)$** | $h_{\text{Manhattan}}(n) \le h^*(n)$. Trong mê cung không có tường, $h_{\text{Manhattan}}(n) = h^*(n)$ (ước lượng hoàn hảo tuyệt đối). | $h_{\text{Euclidean}}(n) \le h_{\text{Manhattan}}(n) \le h^*(n)$. Euclidean luôn đánh giá non hơn (underestimate sâu hơn) Manhattan. |
| **Tính chặt chẽ & Tính trội** | **Chặt chẽ hơn và TRỘI HƠN (Dominates):** $h_{\text{Manhattan}}(n) \ge h_{\text{Euclidean}}(n)$ với mọi trạng thái $n$. | **Kém chặt chẽ hơn:** Giá trị $h$ nhỏ hơn thực tế nhiều, chỉ bằng Manhattan khi hai ô cùng hàng hoặc cùng cột. |
| **Độ mở rộng của A* Search** | **Mở rộng ÍT NÚT HƠN:** Do $h$ sát $h^*$ hơn, đường đồng mức $f(n) \le C^*$ co cụm hẹp hơn, giúp thuật toán tới đích nhanh hơn. | **Mở rộng NHIỀU NÚT HƠN:** Vì $h$ nhỏ hơn, nhiều nút đi chệch hướng vẫn có $f(n) \le C^*$ và bị mở rộng dư thừa. |

---

### 3. Hiện tượng đặc thù quan sát được trong thực nghiệm (`06_Explore_heuristics.ipynb`)
* **Hiện tượng cao nguyên bằng phẳng (Plateau) của Manhattan:** Trong mê cung rỗng, mọi đường đi trực tiếp không đi lùi từ S tới G đều có chi phí bằng nhau. Do đó, tất cả các ô trong hình chữ nhật bao quanh S và G đều có $f(n) = g(n) + h(n) = C^*$. Điều này dẫn tới hiện tượng đồng hạng (tie), thuật toán phải duyệt toàn bộ khối chữ nhật này nếu cơ chế phá hòa (tie-breaking) không tốt.
* **Độ dốc ngược của Euclidean:** Như phân tích trong notebook 06, hình học Euclidean không ăn khớp tự nhiên với lưới Manhattan, tạo ra gradient ngược nhẹ từ đích về phía xuất phát, khiến A* dùng Euclidean phải mở rộng vùng trạng thái hình elip rộng hơn đáng kể.

---

## CÂU 11: WEIGHTED A* THAY ĐỔI ĐIỀU GÌ KHI TĂNG TRỌNG SỐ HEURISTIC?

### 1. Công thức và nguyên lý của Weighted A*
Weighted A* sử dụng hàm đánh giá có trọng số:
$$f(n) = g(n) + w \cdot h(n) \quad (w \ge 0)$$
Trong đó $w$ là trọng số làm phồng heuristic (*Heuristic Inflation Factor*).

---

### 2. Những thay đổi cụ thể khi TĂNG trọng số heuristic ($w > 1$)
1. **Tăng tốc độ tìm kiếm và giảm số nút mở rộng:** Khi $w > 1$, thành phần $h(n)$ được phóng đại, tạo ra một độ dốc gradient rất dốc dẫn thẳng từ Start về Goal. Nhờ đó, thuật toán phá vỡ hoàn toàn hiện tượng cao nguyên bằng phẳng (plateau) của A* chuẩn, kiên quyết đi thẳng về đích mà không tò mò duyệt các nhánh xung quanh.
2. **Tiết kiệm mạnh mẽ bộ nhớ:** Do không mở rộng các nút lan man hai bên sườn, kích thước Frontier và số trạng thái lưu trữ trong bộ nhớ giảm đi rõ rệt. Weighted A* giải quyết rất tốt bài toán thiếu RAM trong các không gian tìm kiếm khổng lồ.
3. **Mất tính tối ưu tuyệt đối (Optimality Trade-off):** Khi $w > 1$, giá trị $w \cdot h(n)$ có thể vượt quá chi phí thực tế $h^*(n)$. Heuristic bị mất tính chấp nhận được (Inadmissible). Do đó, thuật toán **KHÔNG CÒN BẢO ĐẢM** tìm ra đường đi ngắn nhất tuyệt đối. Đường đi tìm được thường dài hơn đường tối ưu $C^*$.
4. **Bảo đảm giới hạn cận sai số ($\epsilon$-admissibility):** Mặc dù mất tối ưu tuyệt đối, Weighted A* có một tính chất lý thuyết rất mạnh mẽ: Chi phí đường đi tìm được được bảo đảm không bao giờ vượt quá $w$ lần chi phí tối ưu:
   $$\text{Cost}(\text{solution}) \le w \cdot C^*$$
   Người dùng có thể kiểm soát hoàn toàn mức độ sai số tối đa chấp nhận được.

---

### 3. Phổ chuyển dịch hành vi theo giá trị của $w$

| Giá trị trọng số $w$ | Hành vi của thuật toán | Đặc điểm lời giải & Hiệu năng |
| :--- | :--- | :--- |
| **$w = 0$** | Thoái hóa thành Uniform-Cost Search (UCS) / BFS: $f(n) = g(n)$. | Tìm đường tối ưu tuyệt đối. Tìm kiếm lan tỏa mọi hướng, tốc độ chậm nhất, tốn bộ nhớ nhất. |
| **$0 < w < 1$** | Thiên về tìm kiếm không thông tin (coi trọng chi phí đã đi hơn ước lượng). | Tối ưu nhưng mở rộng nhiều nút hơn A* chuẩn, tìm kiếm chậm chạp quanh điểm Start. |
| **$w = 1$** | A* Search chuẩn: $f(n) = g(n) + h(n)$. | Cân bằng hoàn hảo. Bảo đảm nghiệm tối ưu tuyệt đối $C^*$ nếu $h$ admissible. |
| **$w > 1$** *(ví dụ $w=1.1, 1.5, 5$)* | **Weighted A*:** Ưu tiên hướng đích mạnh mẽ. | Chạy cực nhanh, tiết kiệm bộ nhớ vượt bậc. Đổi lại đường đi có thể dài hơn tối ưu (nhưng $\le w \cdot C^*$). |
| **$w \to \infty$** | Tiến dần về Greedy Best-First Search (GBFS). | Thành phần $g(n)$ trở nên không đáng kể, chỉ còn quan tâm đến việc giảm $h(n)$ và hoàn toàn bỏ qua chi phí đường đi. |

---

# Câu 12: Chi phí quản lý dữ liệu của cycle checking

**Câu hỏi:** Cycle checking làm giảm lặp trạng thái nhưng có thể làm tăng chi phí quản lý dữ liệu như thế nào?

Cycle checking giúp DFS tránh mở rộng một node có trạng thái đã xuất hiện trên đường đi hiện tại. Nhờ vậy, thuật toán tránh đi vòng trên cùng một nhánh và giảm công việc tìm kiếm vô ích. Đổi lại, chương trình phải kiểm tra, lưu trữ và cập nhật các cấu trúc dữ liệu phụ; số node mở rộng giảm không bảo đảm tổng thời gian luôn giảm.

## 1. Chi phí kiểm tra đường đi

Trong `DFS()` của `maze_search.py`, mỗi lần lấy node khỏi stack, chương trình lần theo `parent` để tạo tập `ancestors`, rồi kiểm tra `node.pos in ancestors`.

Nếu đường hiện tại có độ sâu h:

- Lần theo cha và xây tập tổ tiên tốn O(h) thời gian.
- Tập tổ tiên dùng thêm O(h) bộ nhớ.
- Phép kiểm tra thuộc tập trung bình O(1), nhưng tổng công việc vẫn là O(h) vì phải xây lại tập ở mỗi lần pop.

Một cách tối ưu khác là duy trì set của nhánh hiện tại và cập nhật khi đi sâu/quay lui. Khi đó thao tác thêm, xóa, kiểm tra thường O(1), nhưng phải quản lý backtracking chính xác. Đây là hướng cải tiến, không phải cách đang dùng trong bài.

## 2. Chi phí kiểm tra và điều chỉnh frontier

Gọi F là số entry đang chờ trong frontier. Code hiện dùng Python list làm stack.

| Phương án | Công việc quản lý thêm | Chi phí trong cài đặt hiện tại |
|---|---|---|
| `path`: kiểm tra đường hiện tại | Xây tập tổ tiên, kiểm tra chu trình | O(h) mỗi lần pop; vẫn có thể lưu nhiều entry cùng vị trí |
| `unique`: không thêm trạng thái đang có trong frontier | Ngoài kiểm tra nhánh, quét list để tìm vị trí trùng | O(F) cho mỗi láng giềng được xét |
| `move`: đưa trạng thái trùng lên đỉnh stack | Tìm entry cũ, xóa ở giữa list, tạo node mới với cha/chi phí mới và append | Tìm và xóa đều có thể O(F); append trung bình O(1) |

Một dict kết hợp cấu trúc duy trì thứ tự thích hợp có thể giảm chi phí tra cứu/đưa lên đỉnh, nhưng cần thêm bộ nhớ và công việc giữ các cấu trúc đồng bộ. Không thể khẳng định cách quét list hiện tại có chi phí O(1).

Nếu có P lượt pop và K láng giềng được xét, cận trên cho phần quản lý này là O(P × h_max) với `path`, và O(P × h_max + K × F_max) với `unique`/`move`, theo giả thiết thao tác hash trung bình O(1). Đây là phần chi phí quản lý, không phải toàn bộ thời gian chương trình.

## 3. Đánh đổi thời gian và bộ nhớ

- Lưu ít node trùng hơn có thể làm frontier nhỏ hơn, nhưng việc tìm/xóa/cập nhật entry tốn thêm thời gian.
- Với mê cung nhiều chu trình, công việc tránh được thường đáng kể; với mê cung ít chu trình hoặc nhánh rất sâu, chi phí kiểm tra có thể chiếm tỷ lệ lớn.
- Kiểm tra trên nhánh chỉ ngăn chu trình của nhánh đó; cùng trạng thái vẫn có thể được mở rộng lại qua nhánh khác.
- Dùng visited/reached toàn cục là graph search và cần bộ nhớ theo số trạng thái đã phát hiện. DFS trong bài không dùng cấu trúc này để cắt nhánh.
- Bộ đếm quan sát, `WeakSet` đo số Node và các frame hoạt ảnh cũng có chi phí riêng. Không được đồng nhất chi phí đo/vẽ này với chi phí bắt buộc của cycle checking.

## 4. Liên hệ thí nghiệm open_maze

Cùng thứ tự sinh hướng NESW và giới hạn 500 lượt:

| Phương án | Lượt pop | Lần mở rộng | Frontier lớn nhất | Lần mở rộng lại | Kết quả |
|-----------|-----|-----|-----|-----|
| `path`    | 500 | 221 | 328 | 42  | Hết ngân sách          |
| `unique`  | 500 | 250 | 162 | 134 | Hết ngân sách          |
| `move`    | 434 | 211 | 143 |  0  | Tìm được đường 54 bước |

Phương án `move` giảm số lần mở rộng lại và kích thước frontier trong thí nghiệm này, nhưng vẫn phải trả chi phí quét/xóa list. Bảng chưa đủ để kết luận nó luôn nhanh nhất trên mọi mê cung. Hai phương án đầu chưa tìm thấy nghiệm trong 500 lượt; điều đó không chứng minh chúng lặp vô hạn.

**Kết luận:** cycle checking đánh đổi chi phí kiểm tra và cập nhật dữ liệu để giảm số nhánh tìm kiếm dư thừa. Khi đánh giá cần xét đồng thời số node mở rộng, độ sâu, kích thước frontier, bộ nhớ và thời gian; không chỉ nhìn số trạng thái bị lặp.
