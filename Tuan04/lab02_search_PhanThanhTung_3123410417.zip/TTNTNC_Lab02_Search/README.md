# Lab 02: Problem Solving by Search (Tìm kiếm giải quyết vấn đề)

Dự án thực hành môn Trí Tuệ Nhân Tạo Nâng Cao - Phân tích, hiện thực hóa và so sánh các thuật toán tìm kiếm (Uninformed & Informed Search) trên không gian mê cung (Maze Problem).

---

## 👥 Bảng Phân Chia Công Việc Nhóm (4 Thành viên)

| STT | Họ và Tên | Vai trò / Phạm vi phụ trách | File / Notebook phụ trách | Bài tập & Câu hỏi thảo luận | Đóng góp |
|:---:|:---|:---|:---|:---|:---:|
| **1** | **Tùng** | **Uninformed Search & Cấu trúc cơ bản**<br>- Cấu trúc cây tìm kiếm (Node, Garbage collection)<br>- Đặc trưng không gian mê cung ($n, d, m, b$)<br>- BFS, DFS, DLS, IDS | `01_trees.ipynb`<br>`Ex3_Show_all_mazes.ipynb`<br>`02_Maze_Example.ipynb`<br>`03_Maze_Example_Animation.ipynb` | **Bài 1, 2, 3, 4**<br>+ Câu hỏi Q7, Q8 | 25% |
| **2** | **Thái** | **Informed Search & Heuristics**<br>- So sánh BFS vs A* Search<br>- Thử nghiệm Heuristics (Manhattan, Euclidean, Chebyshev)<br>- Admissibility & Dominance | `04_Maze_BFS_vs_A_Star.ipynb`<br>`06_Explore_heuristics.ipynb` | **Bài 5, 6**<br>+ Câu hỏi Q6, Q9, Q10, Q11 | 25% |
| **3** | **Thắng** | **Cycle Checking & Agent Mê cung chính**<br>- Vấn đề kiểm tra chu trình (Cycle/Loop checking)<br>- Hiện thực Agent giải mê cung với các thuật toán<br>- Hỗ trợ Multi-Goal Search | `05_Maze_Example-Animation_Cycle_checking.ipynb`<br>`Ex1_Maze.ipynb`<br>`Ex2_Maze_simplified.ipynb` | **Bài 7, 8**<br>+ Câu hỏi Q12 | 25% |
| **4** | **Thi** | **Benchmark, Phân tích & Tổng hợp Báo cáo**<br>- Chạy bảng Benchmark hiệu năng (Mục 4.2)<br>- Thu thập ảnh minh họa / GIF động (2-4 hình)<br>- Viết phân tích tổng hợp (1-2 trang)<br>- Tổng hợp Q6-Q12 vào Mục 4.3 & Xuất PDF | Toàn bộ Notebooks<br>`Report.docx` / `Report.pdf` | **Mục 4.2 (Benchmark)**<br>**Mục 4.3 (Q6 - Q12)**<br>**Tổng hợp & Hoàn thiện Báo cáo** | 25% |

---

## 📌 Chi Tiết Nhiệm Vụ Từng Thành Viên

### 🔹 1. Tùng: Uninformed Search (Bài 1, 2, 3, 4 + Q7, Q8)
1. **[01_trees.ipynb](01_trees.ipynb) (Bài 1)**:
   - Chạy và kiểm tra toàn bộ code xây dựng cấu trúc cây tìm kiếm.
   - Giải thích 4 thuộc tính cơ bản của `Node` (`pos`, `parent`, `action`, `cost`).
   - Phân tích cơ chế Garbage Collection và bản chất cây không phải nhị phân.
2. **[Ex3_Show_all_mazes.ipynb](Ex3_Show_all_mazes.ipynb) (Bài 2)**:
   - Thống kê thông số ($n, d, m, b$, Start/Goal) cho toàn bộ 8 bản đồ mê cung.
   - Định nghĩa 5 thành phần của bài toán tìm kiếm trên mê cung.
3. **[02_Maze_Example.ipynb](02_Maze_Example.ipynb) & [03_Maze_Example_Animation.ipynb](03_Maze_Example_Animation.ipynb) (Bài 3 & 4)**:
   - So sánh chi tiết BFS vs DFS (Queue vs Stack, Tính đầy đủ, Tối ưu, Bộ nhớ $O(b^d)$ vs $O(b\cdot m)$).
   - Khảo sát Depth-Limited Search (DLS) với các ngưỡng độ sâu ($L < d$ vs $L \ge d$).
   - Phân tích Iterative Deepening Search (IDS), số bước lặp tăng độ sâu và ảnh hưởng của cycle checking.
4. **Viết nội dung lý thuyết**: Trả lời câu **Q7** (BFS vs DFS) và **Q8** (DLS & IDS) để bàn giao cho Thi đưa vào Báo cáo.

---

### 🔹 2. Thái: Informed Search & Heuristics (Bài 5, 6 + Q6, Q9, Q10, Q11)
1. **[04_Maze_BFS_vs_A_Star.ipynb](04_Maze_BFS_vs_A_Star.ipynb) (Bài 5)**:
   - Khảo sát A* Search sử dụng hàm đánh giá $f(n) = g(n) + h(n)$.
   - So sánh không gian trạng thái đã duyệt (expanded nodes) giữa BFS và A*.
2. **[06_Explore_heuristics.ipynb](06_Explore_heuristics.ipynb) (Bài 6)**:
   - So sánh các hàm heuristic khác nhau: Manhattan Distance, Euclidean Distance, Chebyshev Distance, Zero Heuristic ($h=0$).
   - Đánh giá tính chấp nhận được (Admissibility) và tính ưu việt (Dominance) của heuristic trên lưới 4 hướng di chuyển.
3. **Viết nội dung lý thuyết**: Trả lời các câu **Q6** (Greedy Best-First vs A*), **Q9** (A* Properties), **Q10** (Heuristic Comparison), **Q11** (Admissibility & Consistency) bàn giao cho Thi.

---

### 🔹 3. Thắng: Cycle Checking & Agent Mê cung chính (Bài 7, 8 + Q12)
1. **[05_Maze_Example-Animation_Cycle_checking.ipynb](05_Maze_Example-Animation_Cycle_checking.ipynb) (Bài 7)**:
   - Khảo sát các kỹ thuật kiểm tra chu trình: Không kiểm tra, Kiểm tra trên đường đi (Path/Branch checking), Kiểm tra toàn cục (Visited set).
   - Phân tích hiện tượng lặp vô tận của DFS và tác động đến tính đầy đủ.
2. **[Ex1_Maze.ipynb](Ex1_Maze.ipynb) / [Ex2_Maze_simplified.ipynb](Ex2_Maze_simplified.ipynb) (Bài 8 - Bài tập lớn cốt lõi)**:
   - Hiện thực Agent giải mê cung tích hợp các thuật toán: BFS, DFS, UCS, Greedy Best-First Search, A* Search.
   - Hiện thực mở rộng tìm kiếm đa mục tiêu (Multi-Goal Search) nếu có yêu cầu.
   - Đảm bảo code chạy mượt mà, trả về kết quả đường đi, số node đã duyệt, chi phí đường đi.
3. **Viết nội dung lý thuyết**: Trả lời câu **Q12** (Cycle Checking vs Graph Search) bàn giao cho Thi.

---

### 🔹 4. Thi: Benchmark, Tổng hợp Báo cáo & Trực quan hóa
1. **Bảng Benchmark Đánh giá Hiệu năng (Mục 4.2)**:
   - Lấy code của Thắng chạy đo đạc trên 8 mê cung (`small`, `medium`, `large`, `open`, `L`, `loops`, `empty`, `empty_2`).
   - Lập bảng so sánh các thuật toán (BFS, DFS, A* Manhattan, A* Euclidean, v.v.) theo các chỉ số:
     - Độ dài đường đi (Path Length / Cost).
     - Số trạng thái đã mở rộng (Expanded Nodes / States Visited).
     - Thời gian thực thi (Runtime / Execution Time).
2. **Trực quan hóa & Đồ thị minh họa (Section 4.1)**:
   - Thu thập 2–4 hình ảnh / GIF animation biểu diễn quá trình tìm kiếm của các thuật toán trên các dạng mê cung đặc thù (Loop maze, Open maze).
3. **Viết phân tích & Đánh giá (1-2 trang)**:
   - Viết phần nhận xét chi tiết: thuật toán nào tối ưu nhất? Khi nào A* vượt trội BFS? Hạn chế của DFS trong không gian có chu trình?
4. **Hoàn thiện Báo cáo (PDF)**:
   - Tập hợp câu trả lời **Q6 đến Q12** từ Tùng, Thái, Thắng vào **Mục 4.3 (Questions for Discussion)**.
   - Thêm trang bìa chuẩn, mục lục, bảng phân chia công việc nhóm.
   - Rà soát toàn bộ notebook và xuất file báo cáo cuối cùng `Report_Group_Lab02.pdf`.

---

## 📂 Cấu Trúc Thư Mục Dự Án

```text
TTNTNC_Lab02_Search/
├── 01_trees.ipynb                                      # Bài 1: Cấu trúc cây tìm kiếm (Tùng)
├── 02_Maze_Example.ipynb                               # Bài 3, 4: So sánh BFS/DFS & DLS/IDS (Tùng)
├── 03_Maze_Example_Animation.ipynb                     # Bài 3, 4: Animation BFS vs DFS (Tùng)
├── 04_Maze_BFS_vs_A_Star.ipynb                         # Bài 5: So sánh BFS vs A* (Thái)
├── 05_Maze_Example-Animation_Cycle_checking.ipynb      # Bài 7: Kiểm tra chu trình & Graph Search (Thắng)
├── 06_Explore_heuristics.ipynb                         # Bài 6: Khảo sát Heuristics (Thái)
├── Ex1_Maze.ipynb                                      # Bài 8: Agent giải mê cung chính (Thắng)
├── Ex2_Maze_simplified.ipynb                           # Bài tập bổ trợ BFS rút gọn (Thắng)
├── Ex3_Show_all_mazes.ipynb                            # Bài 2: Phân tích 8 mê cung đề bài (Tùng)
├── maze.py / tree_search.py / utils.py                 # Mã nguồn hỗ trợ không gian mê cung
└── README.md                                           # Bảng phân công & hướng dẫn dự án
```

---

## 🚀 Hướng Dẫn Thực Hiện & Phối Hợp Nhóm

1. **Lưu ý quan trọng về các Notebook Demo**:
   - `02_Maze_Example.ipynb` và `03_Maze_Example_Animation.ipynb` sử dụng module giải sẵn phục vụ quan sát minh họa, không cần restart chạy lại code nếu thiếu module ngoài.
   - Tập trung hiện thực code thuật toán tìm kiếm độc lập trong file **`Ex1_Maze.ipynb`**.
2. **Quy trình phối hợp**:
   - **Tùng**, **Thái**, **Thắng** hoàn thành phần notebook và trả lời các câu hỏi lý thuyết tương ứng của mình.
   - **Thi** lấy kết quả đo đạc từ code của **Thắng** để tổng hợp bảng Benchmark, ghép phần lý thuyết của cả nhóm vào Báo cáo và xuất ra file PDF hoàn chỉnh.
3. **Sản phẩm nộp**:
   - Toàn bộ source code và các file `.ipynb` đã chạy hoàn chỉnh.
   - File báo cáo định dạng **PDF** bao gồm đầy đủ trang bìa, bảng phân công, biểu đồ, bảng benchmark và phần trả lời câu hỏi thảo luận Q6 - Q12.
