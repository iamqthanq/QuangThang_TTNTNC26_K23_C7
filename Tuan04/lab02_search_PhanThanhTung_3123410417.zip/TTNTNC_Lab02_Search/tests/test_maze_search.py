"""Behavioral checks: reference shortest paths, cycles, cutoffs and planning."""
from collections import deque
import itertools

import numpy as np
import pytest

import maze_search as ms


def reference_distance(maze, start, goals):
    queue, seen = deque([(start, 0)]), {start}
    while queue:
        (r, c), d = queue.popleft()
        if (r, c) in goals:
            return d
        for dr, dc in [(-1, 0), (0, 1), (1, 0), (0, -1)]:
            p = (r + dr, c + dc)
            if (0 <= p[0] < maze.shape[0] and 0 <= p[1] < maze.shape[1]
                    and maze[p] != 'X' and p not in seen):
                seen.add(p)
                queue.append((p, d + 1))
    return None


def check_path(maze, result, start, goals):
    assert result['path'][0] == start
    assert result['path'][-1] in goals
    assert result['cost'] == len(result['actions']) == len(result['path']) - 1
    assert ms.execute_plan(maze, start, result['actions']) == result['path']
    assert len(set(result['path'])) == len(result['path'])


def test_all_three_by_three_wall_layouts():
    """Independent oracle on all 128 layouts, including disconnected/cyclic ones."""
    free = [(r, c) for r in range(3) for c in range(3) if (r, c) not in [(0, 0), (2, 2)]]
    for bits in itertools.product([False, True], repeat=len(free)):
        maze = np.full((3, 3), ' ')
        for pos, wall in zip(free, bits):
            if wall:
                maze[pos] = 'X'
        maze[0, 0], maze[2, 2] = 'S', 'G'
        original = maze.copy()
        expected = reference_distance(maze, (0, 0), {(2, 2)})
        for algorithm in [ms.BFS, ms.DFS, ms.GBFS, ms.A_star, ms.IDS]:
            result = algorithm(maze, max_iterations=10000)
            assert result['status'] == ('failure' if expected is None else 'found')
            if expected is not None:
                check_path(maze, result, (0, 0), {(2, 2)})
                if algorithm in [ms.BFS, ms.A_star, ms.IDS]:
                    assert result['cost'] == expected
            assert np.array_equal(maze, original)


@pytest.mark.parametrize('name', ms.MAZE_NAMES)
def test_supplied_mazes(name):
    maze = ms.load_maze(name)
    start, goals = tuple(np.argwhere(maze == 'S')[0]), ms.find_goals(maze)
    expected = reference_distance(maze, start, goals)
    for algorithm in [ms.BFS, ms.DFS, ms.GBFS, ms.A_star]:
        result = algorithm(maze, max_iterations=10000)
        assert result['status'] == 'found'
        check_path(maze, result, start, goals)
        if algorithm in [ms.BFS, ms.A_star]:
            assert result['cost'] == expected


def test_cycles_and_diagnostic_isolation():
    maze = ms.load_maze('open')
    for policy in ['path', 'unique', 'move']:
        measured = ms.DFS(maze, frontier_policy=policy, max_iterations=500)
        plain = ms.DFS(maze, frontier_policy=policy, max_iterations=500, record=False)
        for field in ['status', 'path', 'actions', 'iterations', 'expanded', 'max_depth', 'max_frontier']:
            assert measured[field] == plain[field]
        assert plain['reached'] == set()
        if policy == 'move':
            assert measured['status'] == 'found' and measured['cost'] == 54
            assert measured['reexpanded'] == 0
        else:
            assert measured['status'] == 'limit' and measured['reexpanded'] > 0


def test_limits_failure_and_zero_length_plan():
    corridor = np.array([list('S  G')])
    assert ms.IDS(corridor, max_depth=2)['status'] == 'cutoff'
    assert ms.IDS(corridor, max_iterations=2)['status'] == 'limit'
    assert ms.IDS(corridor, max_iterations=2)['iterations'] == 2
    assert ms.IDS(corridor, max_iterations=None)['cost'] == 3
    for algorithm in ms.ALGORITHMS.values():
        assert algorithm(corridor, goals=(0, 0))['cost'] == 0
        assert algorithm(np.array([list('SXG')]))['status'] == 'failure'
    with pytest.raises(ValueError):
        ms.DFS(corridor, depth_limit=1)  # DLS cannot deduplicate by position only.
    with pytest.raises(RuntimeError):
        ms.plan_search(corridor, (0, 0), (0, 3), max_iterations=1)


def test_multiple_goals_and_agent_execution():
    maze = np.array([list('S  G'), list(' XX '), list('G   ')])
    for algorithm in [ms.BFS, ms.A_star, ms.IDS]:
        result = algorithm(maze)
        assert result['cost'] == 2 and result['goal'] == (2, 0)
    calls = []

    def planner(m, s, g):
        calls.append(1)
        return ms.plan_search(m, s, g)

    agent = ms.PlanningAgent(maze, (0, 0), ms.find_goals(maze), planner)
    actions = [agent.act(), agent.act()]
    with pytest.raises(StopIteration):
        agent.act()
    assert len(calls) == 1
    assert ms.execute_plan(maze, (0, 0), actions)[-1] == (2, 0)
    with pytest.raises(ValueError):
        ms.execute_plan(maze, (0, 0), ['N'])


def test_animation_and_map_are_independent():
    maze = ms.load_maze('small')
    original = maze.copy()
    result = ms.BFS(maze, animation=True)
    assert 2 <= len(result['maze_anim']) <= 122
    result['maze_anim'][0][:] = 'X'
    assert np.array_equal(maze, original)
