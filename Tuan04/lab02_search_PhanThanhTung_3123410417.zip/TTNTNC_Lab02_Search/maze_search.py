"""Search implementations for Thang's Lab 02 notebooks.

Maps are read-only inputs. Search state lives in Nodes/frontier/reached.
Optional diagnostic counts and animation frames never control the search.
"""

from collections import Counter, deque
from dataclasses import dataclass
import heapq
from itertools import count
from pathlib import Path
from time import perf_counter
from weakref import WeakSet

import numpy as np
import maze_helper as mh


DIRECTIONS = {"N": (-1, 0), "E": (0, 1), "S": (1, 0), "W": (0, -1)}
MAZE_NAMES = ("small", "medium", "large", "open", "L", "loops", "empty", "empty_2")


@dataclass(eq=False)
class Node:
    pos: tuple
    parent: object = None
    action: str = None
    cost: int = 0

    def get_path_from_root(self):
        path, node = [], self
        while node is not None:
            path.append(node)
            node = node.parent
        return path[::-1]


def load_maze(name):
    """Read a provided maze name (including empty_2), or a .txt path."""
    filename = "empty_maze_2.txt" if name == "empty_2" else f"{name}_maze.txt"
    path = Path(name) if str(name).endswith(".txt") else Path(filename)
    return mh.parse_maze(path.read_text(encoding="utf-8"))


def find_goals(maze):
    """Return ALL goal positions, unlike maze_helper.find_pos()."""
    return frozenset(map(tuple, np.argwhere(maze == "G")))


def neighbors(maze, pos, order="NESW"):
    """Yield (action, position) for legal orthogonal unit-cost moves."""
    for action in order:
        dr, dc = DIRECTIONS[action]
        nxt = (pos[0] + dr, pos[1] + dc)
        if 0 <= nxt[0] < maze.shape[0] and 0 <= nxt[1] < maze.shape[1]:
            if maze[nxt] != "X":
                yield action, nxt


def manhattan(pos, goals):
    """Admissible, consistent distance to the nearest of the target goals."""
    return min(abs(pos[0] - g[0]) + abs(pos[1] - g[1]) for g in goals)


def _problem(maze, start, goals, order):
    maze = np.asarray(maze)
    if maze.ndim != 2 or not maze.size:
        raise ValueError("maze must be a nonempty rectangular 2-D array")
    if len(order) != 4 or set(order) != set(DIRECTIONS):
        raise ValueError("order must be a permutation of NESW")
    starts = np.argwhere(maze == "S")
    if start is None:
        if len(starts) != 1:
            raise ValueError("maze must contain exactly one S, or pass start explicitly")
        start = tuple(starts[0])
    start = tuple(start)
    if goals is None:
        goals = find_goals(maze)
    elif len(goals) == 2 and all(np.isscalar(x) for x in goals):
        goals = [tuple(goals)]
    goals = frozenset(map(tuple, goals))
    if not goals:
        raise ValueError("at least one goal is required")
    for pos in [start, *goals]:
        if len(pos) != 2 or not (0 <= pos[0] < maze.shape[0] and 0 <= pos[1] < maze.shape[1]):
            raise ValueError(f"position outside maze: {pos}")
        if maze[pos] == "X":
            raise ValueError(f"position is a wall: {pos}")
    return maze, start, goals


def _paint(maze, expanded=(), frontier=(), path=()):
    """Make a visualization copy; never put bookkeeping into the input map."""
    picture = np.copy(maze)
    for positions, tile in [(expanded, "."), (frontier, "F"), (path, "P")]:
        for pos in positions:
            if maze[pos] not in ("S", "G", "X"):
                picture[pos] = tile
    return picture


class _Run:
    """Instrumentation only. The algorithms never read visits to prune nodes."""

    def __init__(self, maze, algorithm, max_iterations, record, animation):
        if max_iterations is not None and (not isinstance(max_iterations, (int, np.integer)) or max_iterations < 1):
            raise ValueError("max_iterations must be a positive integer or None")
        self.maze, self.algorithm = maze, algorithm
        self.max_iterations = max_iterations
        self.started = perf_counter()
        self.iterations = self.expanded = self.max_depth = 0
        self.max_frontier = self.max_nodes = 0
        self.cycle_pruned = self.frontier_skipped = self.frontier_moved = 0
        self.live = WeakSet()  # Does not keep discarded search nodes alive.
        self.visits = Counter() if record else None
        self.animation = animation
        self.frames = [np.copy(maze)] if animation else []
        self.history = [] if animation else None

    def node(self, pos, parent=None, action=None):
        node = Node(pos, parent, action, 0 if parent is None else parent.cost + 1)
        self.live.add(node)
        self.max_nodes = max(self.max_nodes, len(self.live))
        self.max_depth = max(self.max_depth, node.cost)
        return node

    def limited(self):
        return self.max_iterations is not None and self.iterations >= self.max_iterations

    def expand(self, node):
        self.expanded += 1
        if self.visits is not None:
            self.visits[node.pos] += 1

    def observe(self, frontier, node=None, branch_only=False):
        self.max_frontier = max(self.max_frontier, len(frontier))
        if self.animation:
            self.history.append((self.iterations, len(frontier)))
            # At most 120 intermediate frames. Full counters are still measured.
            if self.iterations % 5 == 0 and len(self.frames) < 121:
                path = [] if node is None else [n.pos for n in node.get_path_from_root()]
                expanded = () if branch_only or self.visits is None else self.visits
                self.frames.append(_paint(self.maze, expanded, (n.pos for n in frontier), path))

    def finish(self, status, node=None, frontier=()):
        frontier = list(frontier)
        nodes = [] if node is None else node.get_path_from_root()
        path = [n.pos for n in nodes] if node is not None else None
        actions = [n.action for n in nodes[1:]] if node is not None else None
        if self.animation:
            # Preserve the pending frontier when a run stops at its iteration limit.
            self.frames.append(_paint(self.maze, self.visits or (),
                                      (pending.pos for pending in frontier), path or ()))
            final_point = (self.iterations, len(frontier))
            if not self.history or self.history[-1] != final_point:
                self.history.append(final_point)
        unique = len(self.visits) if self.visits is not None else None
        return {
            "algorithm": self.algorithm, "status": status, "path": path,
            "actions": actions, "cost": None if node is None else node.cost,
            "goal": None if node is None else node.pos,
            "iterations": self.iterations, "expanded": self.expanded,
            "max_depth": self.max_depth, "max_frontier": self.max_frontier,
            "frontier_remaining": len(frontier),
            "max_nodes": self.max_nodes, "unique_expanded": unique,
            "reexpanded": None if unique is None else self.expanded - unique,
            "cycle_pruned": self.cycle_pruned, "frontier_skipped": self.frontier_skipped,
            "frontier_moved": self.frontier_moved,
            "seconds": perf_counter() - self.started,
            # 'reached' below is observer output, not a DFS pruning structure.
            "reached": set(self.visits or ()), "visit_counts": dict(self.visits or {}),
            "maze_anim": self.frames, "frontier_history": self.history or [],
        }


def BFS(maze, start=None, goals=None, order="NESW", max_iterations=None,
        record=True, animation=False):
    """Graph BFS: mark a state reached when enqueueing, with a FIFO frontier."""
    maze, start, goals = _problem(maze, start, goals, order)
    run = _Run(maze, "BFS", max_iterations, record, animation)
    root = run.node(start)
    frontier, reached = deque([root]), {start}
    del root
    run.observe(frontier)
    while frontier:
        if run.limited():
            return run.finish("limit", frontier=frontier)
        node = frontier.popleft()
        run.iterations += 1
        if node.pos in goals:
            return run.finish("found", node, frontier)
        run.expand(node)
        for action, pos in neighbors(maze, node.pos, order):
            if pos not in reached:
                reached.add(pos)
                frontier.append(run.node(pos, node, action))
        run.observe(frontier, node)
    return run.finish("failure")


def DFS(maze, start=None, goals=None, order="NESW", frontier_policy="move",
        depth_limit=None, max_iterations=None, record=True, animation=False):
    """DFS without a global reached/visited pruning structure.

    path: check ancestors on pop; duplicate frontier entries are allowed.
    unique: skip a successor already in the frontier.
    move: remove the old frontier entry and append a NEW node with current parent.
    DLS must use path policy: frontier deduplication can discard a shallower route.
    """
    if frontier_policy not in ("path", "unique", "move"):
        raise ValueError("frontier_policy must be path, unique, or move")
    if depth_limit is not None and (not isinstance(depth_limit, (int, np.integer))
                                    or depth_limit < 0 or frontier_policy != "path"):
        raise ValueError("DLS requires a nonnegative integer depth_limit and frontier_policy='path'")
    maze, start, goals = _problem(maze, start, goals, order)
    run = _Run(maze, "DFS" if depth_limit is None else "DLS", max_iterations, record, animation)
    frontier = [run.node(start)]
    cutoff = False
    run.observe(frontier, branch_only=True)
    while frontier:
        if run.limited():
            return run.finish("limit", frontier=frontier)
        node = frontier.pop()
        run.iterations += 1
        ancestors, parent = set(), node.parent
        while parent is not None:
            ancestors.add(parent.pos)
            parent = parent.parent
        if node.pos in ancestors:
            run.cycle_pruned += 1
            run.observe(frontier, branch_only=True)
            continue
        if node.pos in goals:
            return run.finish("found", node, frontier)
        if depth_limit is not None and node.cost == depth_limit:
            # Cutoff differs from failure: at least one simple path can go deeper.
            cutoff |= any(pos not in ancestors for _, pos in neighbors(maze, node.pos, order))
            run.observe(frontier, node, branch_only=True)
            continue
        run.expand(node)
        for action, pos in neighbors(maze, node.pos, order):
            if frontier_policy != "path":
                index = next((i for i, pending in enumerate(frontier) if pending.pos == pos), None)
                if index is not None:
                    if frontier_policy == "unique":
                        run.frontier_skipped += 1
                        continue
                    frontier.pop(index)
                    run.frontier_moved += 1
            frontier.append(run.node(pos, node, action))
        run.observe(frontier, node, branch_only=True)
    return run.finish("cutoff" if cutoff else "failure")


def _best_first(maze, start, goals, order, algorithm, heuristic,
                max_iterations, record, animation):
    maze, start, goals = _problem(maze, start, goals, order)
    run = _Run(maze, algorithm, max_iterations, record, animation)
    serial = count()  # Deterministic tie breaking; Nodes are not compared.
    frontier = []
    best_cost = {start: 0}

    def push(node):
        h = 0 if algorithm == "UCS" else heuristic(node.pos, goals)
        priority = h if algorithm == "GBFS" else node.cost + h
        heapq.heappush(frontier, (priority, next(serial), node))

    push(run.node(start))
    run.observe([entry[2] for entry in frontier])
    while frontier:
        if run.limited():
            return run.finish("limit", frontier=(entry[2] for entry in frontier))
        _, _, node = heapq.heappop(frontier)
        run.iterations += 1
        if node.cost != best_cost[node.pos]:
            continue  # Obsolete heap entry from a previously longer route.
        if node.pos in goals:
            return run.finish("found", node, (entry[2] for entry in frontier))
        run.expand(node)
        for action, pos in neighbors(maze, node.pos, order):
            cost = node.cost + 1
            # GBFS keeps first discovery. UCS/A* reopen on a strictly better g.
            improve = pos not in best_cost or (algorithm in ("UCS", "A*") and cost < best_cost[pos])
            if improve:
                best_cost[pos] = cost
                push(run.node(pos, node, action))
        # Avoid walking the entire heap in ordinary, non-animation benchmarks.
        run.max_frontier = max(run.max_frontier, len(frontier))
        if animation:
            run.observe([entry[2] for entry in frontier], node)
    return run.finish("failure")


def UCS(maze, start=None, goals=None, order="NESW", max_iterations=None,
        record=True, animation=False):
    """Uniform-cost graph search, ordered by g; edges in these mazes cost one."""
    return _best_first(maze, start, goals, order, "UCS", None, max_iterations, record, animation)


def GBFS(maze, start=None, goals=None, order="NESW", heuristic=manhattan,
         max_iterations=None, record=True, animation=False):
    return _best_first(maze, start, goals, order, "GBFS", heuristic, max_iterations, record, animation)


def A_star(maze, start=None, goals=None, order="NESW", heuristic=manhattan,
           max_iterations=None, record=True, animation=False):
    return _best_first(maze, start, goals, order, "A*", heuristic, max_iterations, record, animation)


def IDS(maze, start=None, goals=None, order="NESW", max_depth=None,
        max_iterations=100_000, record=True):
    """Iterative DLS with branch checking; budget is shared across ALL rounds."""
    maze, start, goals = _problem(maze, start, goals, order)
    if max_iterations is not None and (not isinstance(max_iterations, (int, np.integer)) or max_iterations < 1):
        raise ValueError("max_iterations must be a positive integer or None")
    if max_depth is not None and (not isinstance(max_depth, (int, np.integer)) or max_depth < 0):
        raise ValueError("max_depth must be a nonnegative integer or None")
    simple_bound = int(np.count_nonzero(maze != "X")) - 1
    max_depth = simple_bound if max_depth is None else min(max_depth, simple_bound)
    if max_depth < 0:
        raise ValueError("max_depth must be nonnegative")
    begun = perf_counter()
    totals = {key: 0 for key in ("iterations", "expanded", "cycle_pruned")}
    peaks = {key: 0 for key in ("max_depth", "max_frontier", "max_nodes")}
    visits, rounds = Counter(), []
    for depth in range(max_depth + 1):
        remaining = None if max_iterations is None else max_iterations - totals["iterations"]
        if remaining is not None and remaining <= 0:
            result["status"] = "limit"
            break
        result = DFS(maze, start, goals, order, frontier_policy="path", depth_limit=depth,
                     max_iterations=remaining, record=record)
        rounds.append({"depth_limit": depth, "status": result["status"],
                       "iterations": result["iterations"], "expanded": result["expanded"]})
        for key in totals:
            totals[key] += result[key]
        for key in peaks:
            peaks[key] = max(peaks[key], result[key])
        visits.update(result["visit_counts"])
        if result["status"] in ("found", "failure", "limit"):
            break
    result.update(totals)
    result.update(peaks)
    result.update(algorithm="IDS", seconds=perf_counter() - begun, rounds=rounds,
                  depth_limit=rounds[-1]["depth_limit"], visit_counts=dict(visits),
                  reached=set(visits), unique_expanded=len(visits) if record else None,
                  reexpanded=totals["expanded"] - len(visits) if record else None)
    return result


ALGORITHMS = {"BFS": BFS, "DFS": DFS, "UCS": UCS, "GBFS": GBFS, "A*": A_star, "IDS": IDS}


def plan_search(maze, start, goal, algorithm="A*", **kwargs):
    """Adapter: return an action list for the agent; distinguish failure/limits."""
    result = ALGORITHMS[algorithm](maze, start=start, goals=goal, **kwargs)
    if result["status"] in ("limit", "cutoff"):
        raise RuntimeError(f"Planning incomplete: {result['status']}")
    return result["actions"]


class PlanningAgent:
    def __init__(self, maze, start, goal, planning_function=plan_search):
        self.maze, self.start, self.goal = maze, start, goal
        self.planning_function = planning_function
        self.plan, self.progress, self.planned = None, 0, False

    def act(self):
        """Plan once, then return the next action on each call."""
        if not self.planned:
            self.plan = self.planning_function(self.maze, self.start, self.goal)
            self.planned = True
        if self.plan is None:
            raise ValueError("No path exists to a goal")
        if self.progress >= len(self.plan):
            raise StopIteration("Completed plan")
        action = self.plan[self.progress]
        self.progress += 1
        return action


def execute_plan(maze, start, actions):
    """Validate every action against the real maze; return the traversed path."""
    pos, path = tuple(start), [tuple(start)]
    for action in actions:
        legal = dict(neighbors(maze, pos))
        if action not in legal:
            raise ValueError(f"Invalid action {action} at {pos}")
        pos = legal[action]
        path.append(pos)
    return path


def show_result(maze, result):
    """Plot explored states and the final path using the supplied maze helper."""
    print(f"{result['algorithm']}: {result['status']}, cost={result['cost']}, "
          f"expanded={result['expanded']}, max frontier={result['max_frontier']}")
    mh.show_maze(_paint(maze, result["reached"], path=result["path"] or ()))


def result_row(name, result):
    """Compact benchmark row; the full path/actions remain in result."""
    fields = ("algorithm", "status", "cost", "iterations", "expanded", "max_depth",
              "max_frontier", "max_nodes", "unique_expanded", "reexpanded", "seconds")
    return {"maze": name, **{key: result[key] for key in fields}}


def plot_results(maze, results, title=""):
    """Compare solutions in one figure; preserve and label every S/G tile."""
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap

    cmap = ListedColormap(['white', 'black', 'blue', 'green', 'red', 'gray', 'orange'])
    codes = {' ': 0, 'X': 1, 'S': 2, 'G': 3, 'P': 4, '.': 5, 'F': 6}
    fig, axes = plt.subplots(1, len(results), figsize=(4 * len(results), 5), squeeze=False)
    for ax, result in zip(axes[0], results):
        painted = _paint(maze, result['reached'], path=result['path'] or ())
        matrix = np.array([[codes[tile] for tile in row] for row in painted])
        ax.imshow(matrix, cmap=cmap, norm=BoundaryNorm(range(8), 7))
        for tile in ('S', 'G'):
            for r, c in np.argwhere(maze == tile):
                ax.text(c, r, tile, color='white', ha='center', va='center', fontsize=8)
        ax.set_title(f"{result['algorithm']} | {result['status']}\ncost={result['cost']}, expanded={result['expanded']}")
        ax.set_xticks([])
        ax.set_yticks([])
    fig.suptitle(title)
    fig.tight_layout()
    plt.show()
